#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Union untuk menyimpan jenis item di perpustakaan
union Item {
    char kategori[20];
    int edisi;
};

// Enum untuk status buku
enum StatusBuku {
    TERSEDIA,
    DIPINJAM
};

// Struct untuk informasi buku4
struct Buku {
    char judul[50];
    char penulis[50];
    int tahun;  // Tahun disimpan sebagai integer
    enum StatusBuku status;
    union Item infoTambahan;
};

// Fungsi untuk memeriksa apakah input hanya berisi angka
int isAngka(const char* str) {
    int panjang = strlen(str);
    for (int i = 0; i < panjang; i++) {
        if (!isdigit(str[i])) {  // Cek apakah karakter bukan angka
            return 0;  // Jika ada karakter selain angka, return 0
        }
    }
    return 1;  // Semua karakter adalah angka
}

// Fungsi untuk menambahkan buku baru
struct Buku* tambahBuku(int* jumlah) {
    struct Buku* bukuBaru = (struct Buku*)malloc(sizeof(struct Buku));
    if (bukuBaru == NULL) {
        printf("Gagal mengalokasikan memori.\n");
        exit(1);
    }
    printf("Masukkan judul buku: ");
    scanf(" %[^\n]", bukuBaru->judul);
    printf("Masukkan penulis buku: ");
    scanf(" %[^\n]", bukuBaru->penulis);

    // Input tahun terbit hanya berupa angka
    int validTahun = 0;
    do {
        printf("Masukkan tahun terbit: ");
        char tahunStr[20];
        scanf(" %[^\n]", tahunStr);

        if (isAngka(tahunStr)) {
            bukuBaru->tahun = atoi(tahunStr);
            validTahun = 1;
        } else {
            printf("Error: Tahun terbit harus berupa angka.\n");
        }
    } while (!validTahun);

    bukuBaru->status = TERSEDIA;

    // Menambahkan info tambahan
    int pilihan;
    do {
        printf("Masukkan jenis info tambahan (1 untuk kategori, 2 untuk edisi): ");
        if (scanf("%d", &pilihan) != 1) {
            printf("Input tidak valid, silakan coba lagi.\n");
            while (getchar() != '\n');
            continue;
        }

        if (pilihan == 1) {
            printf("Masukkan kategori: ");
            scanf(" %[^\n]", bukuBaru->infoTambahan.kategori);
            break;
        } else if (pilihan == 2) {
            printf("Masukkan edisi: ");
            scanf("%d", &bukuBaru->infoTambahan.edisi);
            break;
        } else {
            printf("Pilihan tidak valid. Silakan coba lagi.\n");
        }
    } while (1);

    (*jumlah)++;
    return bukuBaru;
}

// Fungsi untuk menampilkan semua buku
void tampilkanBuku(struct Buku* daftarBuku[], int jumlah) {
    printf("\nDaftar Buku Perpustakaan:\n");
    for (int i = 0; i < jumlah; i++) {
        printf("Buku %d:\n", i + 1);
        printf("Judul: %s\n", daftarBuku[i]->judul);
        printf("Penulis: %s\n", daftarBuku[i]->penulis);
        printf("Tahun Terbit: %d\n", daftarBuku[i]->tahun);
        printf("Status: %s\n", daftarBuku[i]->status == TERSEDIA ? "Tersedia" : "Dipinjam");
        if (daftarBuku[i]->infoTambahan.kategori[0] != '\0') {
            printf("Kategori: %s\n", daftarBuku[i]->infoTambahan.kategori);
        } else {
            printf("Edisi: %d\n", daftarBuku[i]->infoTambahan.edisi);
        }
        printf("\n");
    }
}

// Fungsi untuk mengedit data buku
void editBuku(struct Buku* daftarBuku[], int jumlah) {
    int index;
    printf("Masukkan nomor buku yang ingin diedit (1 - %d): ", jumlah);
    scanf("%d", &index);
    while (getchar() != '\n');

    if (index < 1 || index > jumlah) {
        printf("Nomor buku tidak valid.\n");
        return;
    }

    struct Buku* buku = daftarBuku[index - 1];
    printf("\n=== Edit Buku ===\n");

    // Edit Judul
    printf("Masukkan judul baru (atau -1 untuk tidak mengubah): ");
    char judulBaru[50];
    fgets(judulBaru, sizeof(judulBaru), stdin);
    judulBaru[strcspn(judulBaru, "\n")] = '\0';
    if (strcmp(judulBaru, "-1") != 0) {
        strcpy(buku->judul, judulBaru);
    }

    // Edit Penulis
    printf("Masukkan penulis baru (atau -1 untuk tidak mengubah): ");
    char penulisBaru[50];
    fgets(penulisBaru, sizeof(penulisBaru), stdin);
    penulisBaru[strcspn(penulisBaru, "\n")] = '\0';
    if (strcmp(penulisBaru, "-1") != 0) {
        strcpy(buku->penulis, penulisBaru);
    }

    // Edit Tahun
    printf("Masukkan tahun terbit baru (atau -1 untuk tidak mengubah): ");
    char tahunBaru[20];
    fgets(tahunBaru, sizeof(tahunBaru), stdin);
    tahunBaru[strcspn(tahunBaru, "\n")] = '\0';
    if (strcmp(tahunBaru, "-1") != 0) {
        if (isAngka(tahunBaru)) {
            buku->tahun = atoi(tahunBaru);
        } else {
            printf("Error: Tahun terbit harus berupa angka.\n");
        }
    }

    // Edit Status
    printf("Masukkan status baru (0 untuk Tersedia, 1 untuk Dipinjam, atau -1 untuk tidak mengubah): ");
    char statusBaru[10];
    fgets(statusBaru, sizeof(statusBaru), stdin);
    statusBaru[strcspn(statusBaru, "\n")] = '\0';
    if (strcmp(statusBaru, "-1") != 0) {
        int status = atoi(statusBaru);
        if (status == 0 || status == 1) {
            buku->status = status;
        } else {
            printf("Error: Status harus berupa 0 atau 1.\n");
        }
    }

    // Edit Info Tambahan
    printf("Masukkan jenis info tambahan baru (1 untuk kategori, 2 untuk edisi, atau -1 untuk tidak mengubah): ");
    char pilihan[10];
    fgets(pilihan, sizeof(pilihan), stdin);
    pilihan[strcspn(pilihan, "\n")] = '\0';
    if (strcmp(pilihan, "-1") != 0) {
        int pilihanInt = atoi(pilihan);
        if (pilihanInt == 1) {
            printf("Masukkan kategori baru: ");
            char kategoriBaru[20];
            fgets(kategoriBaru, sizeof(kategoriBaru), stdin);
            kategoriBaru[strcspn(kategoriBaru, "\n")] = '\0';
            strcpy(buku->infoTambahan.kategori, kategoriBaru);
        } else if (pilihanInt == 2) {
            printf("Masukkan edisi baru: ");
            char edisiBaru[10];
            fgets(edisiBaru, sizeof(edisiBaru), stdin);
            edisiBaru[strcspn(edisiBaru, "\n")] = '\0';
            if (isAngka(edisiBaru)) {
                buku->infoTambahan.edisi = atoi(edisiBaru);
            } else {
                printf("Error: Edisi harus berupa angka.\n");
            }
        } else {
            printf("Pilihan tidak valid. Tidak ada perubahan pada info tambahan.\n");
        }
    }
}

// Fungsi utama
int main() {
    int jumlahBuku = 0;
    struct Buku* daftarBuku[100];

    int pilihan;
    do {
        printf("=== Menu Perpustakaan ===\n");
        printf("1. Tambah Buku\n");
        printf("2. Tampilkan Buku\n");
        printf("3. Edit Buku\n");
        printf("4. Keluar\n");
        printf("Masukkan pilihan: ");
        if (scanf("%d", &pilihan) != 1) {
            printf("Input tidak valid.\n");
            while (getchar() != '\n');
            continue;
        }

        switch (pilihan) {
            case 1:
                daftarBuku[jumlahBuku] = tambahBuku(&jumlahBuku);
                break;
            case 2:
                if (jumlahBuku > 0) {
                    tampilkanBuku(daftarBuku, jumlahBuku);
                } else {
                    printf("Tidak ada buku di perpustakaan.\n");
                }
                break;
            case 3:
                if (jumlahBuku > 0) {
                    editBuku(daftarBuku, jumlahBuku);
                } else {
                    printf("Tidak ada buku untuk diedit.\n");
                }
                break;
            case 4:
                printf("Terima kasih telah menggunakan sistem perpustakaan.\n");
                break;
            default:
                printf("Pilihan tidak valid.\n");
                break;
        }
    } while (pilihan != 4);

    // Membersihkan memori yang dialokasikan
    for (int i = 0; i < jumlahBuku; i++) {
        free(daftarBuku[i]);
    }

    return 0;
}
